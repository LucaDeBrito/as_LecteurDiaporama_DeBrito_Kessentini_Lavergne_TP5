#include "basededonnees.h"
#include <QCoreApplication>
baseDeDonnees::baseDeDonnees()
{
    db = QSqlDatabase::addDatabase(CONNECT_TYPE);
    db.setHostName("lakartxela.iutbayonne.univ-pau.fr");
    db.setPort(3306);
    db.setDatabaseName(DATABASE_NAME);
    db.setUserName("elavergne001_bd");
    db.setPassword("elavergne001_bd");
    bool ok = openDatabase();
    qDebug()<<ok;
}

bool baseDeDonnees::openDatabase()
{
    return db.open();
}

void baseDeDonnees::closeDatabase()
{
    db.close();
}


