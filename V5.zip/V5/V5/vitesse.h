#ifndef VITESSE_H
#define VITESSE_H

#include <QDialog>

namespace Ui {
class Vitesse;
}

class Vitesse : public QDialog
{
    Q_OBJECT

public:
    explicit Vitesse(QWidget *parent = nullptr);
    ~Vitesse();
    float getSpeed();

public slots:
    void setSpeed();
    void setSpeed025();
    void setSpeed05();
    void setSpeed075();
    void setSpeed125();
    void setSpeed15();
    void setSpeed175();
    void setSpeed2();

private:
    Ui::Vitesse *ui;
    int speed;
};

#endif // VITESSE_H
