#include "choixdiapo.h"
#include "ui_choixdiapo.h"

ChoixDiapo::ChoixDiapo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChoixDiapo)
{
    ui->setupUi(this);
}

ChoixDiapo::~ChoixDiapo()
{
    delete ui;
}

int ChoixDiapo::getNumDiapo()
{
    return ui->numDiaporama->value();
}
