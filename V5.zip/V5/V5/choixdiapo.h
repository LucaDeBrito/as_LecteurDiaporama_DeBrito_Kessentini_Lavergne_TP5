#ifndef CHOIXDIAPO_H
#define CHOIXDIAPO_H

#include <QDialog>

namespace Ui {
class ChoixDiapo;
}

class ChoixDiapo : public QDialog
{
    Q_OBJECT

public:
    explicit ChoixDiapo(QWidget *parent = nullptr);
    ~ChoixDiapo();
    int getNumDiapo();                  //Permet d'obtenir le numéro du diaporama

private:
    Ui::ChoixDiapo *ui;
};

#endif // CHOIXDIAPO_H
