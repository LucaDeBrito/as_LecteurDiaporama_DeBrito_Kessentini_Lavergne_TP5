/********************************************************************************
** Form generated from reading UI file 'vitesse.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VITESSE_H
#define UI_VITESSE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_Vitesse
{
public:
    QVBoxLayout *verticalLayout;
    QRadioButton *x2;
    QRadioButton *x175;
    QRadioButton *x15;
    QRadioButton *x125;
    QRadioButton *x1;
    QRadioButton *x075;
    QRadioButton *x05;
    QRadioButton *x025;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *Vitesse)
    {
        if (Vitesse->objectName().isEmpty())
            Vitesse->setObjectName(QString::fromUtf8("Vitesse"));
        Vitesse->resize(174, 250);
        verticalLayout = new QVBoxLayout(Vitesse);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        x2 = new QRadioButton(Vitesse);
        x2->setObjectName(QString::fromUtf8("x2"));

        verticalLayout->addWidget(x2);

        x175 = new QRadioButton(Vitesse);
        x175->setObjectName(QString::fromUtf8("x175"));

        verticalLayout->addWidget(x175);

        x15 = new QRadioButton(Vitesse);
        x15->setObjectName(QString::fromUtf8("x15"));

        verticalLayout->addWidget(x15);

        x125 = new QRadioButton(Vitesse);
        x125->setObjectName(QString::fromUtf8("x125"));

        verticalLayout->addWidget(x125);

        x1 = new QRadioButton(Vitesse);
        x1->setObjectName(QString::fromUtf8("x1"));
        x1->setChecked(true);

        verticalLayout->addWidget(x1);

        x075 = new QRadioButton(Vitesse);
        x075->setObjectName(QString::fromUtf8("x075"));

        verticalLayout->addWidget(x075);

        x05 = new QRadioButton(Vitesse);
        x05->setObjectName(QString::fromUtf8("x05"));

        verticalLayout->addWidget(x05);

        x025 = new QRadioButton(Vitesse);
        x025->setObjectName(QString::fromUtf8("x025"));

        verticalLayout->addWidget(x025);

        buttonBox = new QDialogButtonBox(Vitesse);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(Vitesse);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, Vitesse, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, Vitesse, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(Vitesse);
    } // setupUi

    void retranslateUi(QDialog *Vitesse)
    {
        Vitesse->setWindowTitle(QCoreApplication::translate("Vitesse", "Dialog", nullptr));
        x2->setText(QCoreApplication::translate("Vitesse", "x2", nullptr));
        x175->setText(QCoreApplication::translate("Vitesse", "x1,75", nullptr));
        x15->setText(QCoreApplication::translate("Vitesse", "x1,5", nullptr));
        x125->setText(QCoreApplication::translate("Vitesse", "x1,25", nullptr));
        x1->setText(QCoreApplication::translate("Vitesse", "x1", nullptr));
        x075->setText(QCoreApplication::translate("Vitesse", "x0,75", nullptr));
        x05->setText(QCoreApplication::translate("Vitesse", "x0,5", nullptr));
        x025->setText(QCoreApplication::translate("Vitesse", "x0,25", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Vitesse: public Ui_Vitesse {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VITESSE_H
