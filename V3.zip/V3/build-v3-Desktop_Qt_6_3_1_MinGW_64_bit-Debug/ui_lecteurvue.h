/********************************************************************************
** Form generated from reading UI file 'lecteurvue.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LECTEURVUE_H
#define UI_LECTEURVUE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LecteurVue
{
public:
    QAction *quitter;
    QAction *aProposDe;
    QWidget *FenPrincipale;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *AffichageVertical;
    QHBoxLayout *LAffichageMode;
    QSpacerItem *horizontalSpacer_3;
    QLabel *mode;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *LDiaporama;
    QSpacerItem *horizontalSpacer;
    QPushButton *precedent;
    QSpacerItem *horizontalSpacer_10;
    QLabel *Image;
    QSpacerItem *horizontalSpacer_11;
    QPushButton *suivant;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *LInformations;
    QSpacerItem *horizontalSpacer_8;
    QLabel *tTitre;
    QLabel *label_2;
    QLabel *tCategorie;
    QLabel *label_4;
    QLabel *label_3;
    QLabel *tNum;
    QLabel *label_5;
    QLabel *tNbrImage;
    QSpacerItem *horizontalSpacer_9;
    QHBoxLayout *LModeAutoManuel;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *lancer;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *arreter;
    QSpacerItem *horizontalSpacer_7;
    QMenuBar *BarreMenu;
    QMenu *menuFichier;
    QMenu *menuParam;
    QMenu *menuAide;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *LecteurVue)
    {
        if (LecteurVue->objectName().isEmpty())
            LecteurVue->setObjectName(QString::fromUtf8("LecteurVue"));
        LecteurVue->resize(904, 473);
        quitter = new QAction(LecteurVue);
        quitter->setObjectName(QString::fromUtf8("quitter"));
        aProposDe = new QAction(LecteurVue);
        aProposDe->setObjectName(QString::fromUtf8("aProposDe"));
        FenPrincipale = new QWidget(LecteurVue);
        FenPrincipale->setObjectName(QString::fromUtf8("FenPrincipale"));
        verticalLayout = new QVBoxLayout(FenPrincipale);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        AffichageVertical = new QVBoxLayout();
        AffichageVertical->setObjectName(QString::fromUtf8("AffichageVertical"));
        LAffichageMode = new QHBoxLayout();
        LAffichageMode->setObjectName(QString::fromUtf8("LAffichageMode"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LAffichageMode->addItem(horizontalSpacer_3);

        mode = new QLabel(FenPrincipale);
        mode->setObjectName(QString::fromUtf8("mode"));

        LAffichageMode->addWidget(mode);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LAffichageMode->addItem(horizontalSpacer_4);


        AffichageVertical->addLayout(LAffichageMode);

        LDiaporama = new QHBoxLayout();
        LDiaporama->setObjectName(QString::fromUtf8("LDiaporama"));
        horizontalSpacer = new QSpacerItem(48, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LDiaporama->addItem(horizontalSpacer);

        precedent = new QPushButton(FenPrincipale);
        precedent->setObjectName(QString::fromUtf8("precedent"));

        LDiaporama->addWidget(precedent);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LDiaporama->addItem(horizontalSpacer_10);

        Image = new QLabel(FenPrincipale);
        Image->setObjectName(QString::fromUtf8("Image"));

        LDiaporama->addWidget(Image);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LDiaporama->addItem(horizontalSpacer_11);

        suivant = new QPushButton(FenPrincipale);
        suivant->setObjectName(QString::fromUtf8("suivant"));

        LDiaporama->addWidget(suivant);

        horizontalSpacer_2 = new QSpacerItem(68, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LDiaporama->addItem(horizontalSpacer_2);


        AffichageVertical->addLayout(LDiaporama);

        LInformations = new QHBoxLayout();
        LInformations->setObjectName(QString::fromUtf8("LInformations"));
        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LInformations->addItem(horizontalSpacer_8);

        tTitre = new QLabel(FenPrincipale);
        tTitre->setObjectName(QString::fromUtf8("tTitre"));

        LInformations->addWidget(tTitre);

        label_2 = new QLabel(FenPrincipale);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        LInformations->addWidget(label_2);

        tCategorie = new QLabel(FenPrincipale);
        tCategorie->setObjectName(QString::fromUtf8("tCategorie"));

        LInformations->addWidget(tCategorie);

        label_4 = new QLabel(FenPrincipale);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        LInformations->addWidget(label_4);

        label_3 = new QLabel(FenPrincipale);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        LInformations->addWidget(label_3);

        tNum = new QLabel(FenPrincipale);
        tNum->setObjectName(QString::fromUtf8("tNum"));

        LInformations->addWidget(tNum);

        label_5 = new QLabel(FenPrincipale);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        LInformations->addWidget(label_5);

        tNbrImage = new QLabel(FenPrincipale);
        tNbrImage->setObjectName(QString::fromUtf8("tNbrImage"));

        LInformations->addWidget(tNbrImage);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LInformations->addItem(horizontalSpacer_9);


        AffichageVertical->addLayout(LInformations);

        LModeAutoManuel = new QHBoxLayout();
        LModeAutoManuel->setObjectName(QString::fromUtf8("LModeAutoManuel"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LModeAutoManuel->addItem(horizontalSpacer_5);

        lancer = new QPushButton(FenPrincipale);
        lancer->setObjectName(QString::fromUtf8("lancer"));

        LModeAutoManuel->addWidget(lancer);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LModeAutoManuel->addItem(horizontalSpacer_6);

        arreter = new QPushButton(FenPrincipale);
        arreter->setObjectName(QString::fromUtf8("arreter"));
        arreter->setEnabled(false);

        LModeAutoManuel->addWidget(arreter);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        LModeAutoManuel->addItem(horizontalSpacer_7);


        AffichageVertical->addLayout(LModeAutoManuel);


        verticalLayout->addLayout(AffichageVertical);

        LecteurVue->setCentralWidget(FenPrincipale);
        BarreMenu = new QMenuBar(LecteurVue);
        BarreMenu->setObjectName(QString::fromUtf8("BarreMenu"));
        BarreMenu->setGeometry(QRect(0, 0, 904, 22));
        menuFichier = new QMenu(BarreMenu);
        menuFichier->setObjectName(QString::fromUtf8("menuFichier"));
        menuParam = new QMenu(BarreMenu);
        menuParam->setObjectName(QString::fromUtf8("menuParam"));
        menuAide = new QMenu(BarreMenu);
        menuAide->setObjectName(QString::fromUtf8("menuAide"));
        LecteurVue->setMenuBar(BarreMenu);
        statusbar = new QStatusBar(LecteurVue);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        LecteurVue->setStatusBar(statusbar);

        BarreMenu->addAction(menuFichier->menuAction());
        BarreMenu->addAction(menuParam->menuAction());
        BarreMenu->addAction(menuAide->menuAction());
        menuFichier->addAction(quitter);
        menuAide->addAction(aProposDe);

        retranslateUi(LecteurVue);

        QMetaObject::connectSlotsByName(LecteurVue);
    } // setupUi

    void retranslateUi(QMainWindow *LecteurVue)
    {
        LecteurVue->setWindowTitle(QCoreApplication::translate("LecteurVue", "LecteurVue", nullptr));
        quitter->setText(QCoreApplication::translate("LecteurVue", "Quitter", nullptr));
#if QT_CONFIG(shortcut)
        quitter->setShortcut(QCoreApplication::translate("LecteurVue", "Ctrl+Q", nullptr));
#endif // QT_CONFIG(shortcut)
        aProposDe->setText(QCoreApplication::translate("LecteurVue", "A propos de\342\200\246", nullptr));
        mode->setText(QCoreApplication::translate("LecteurVue", "Mode : ____", nullptr));
        precedent->setText(QCoreApplication::translate("LecteurVue", "Pr\303\251c\303\251dent", nullptr));
        Image->setText(QCoreApplication::translate("LecteurVue", "TextLabel", nullptr));
        suivant->setText(QCoreApplication::translate("LecteurVue", "Suivant", nullptr));
        tTitre->setText(QCoreApplication::translate("LecteurVue", "Titre", nullptr));
        label_2->setText(QCoreApplication::translate("LecteurVue", "|", nullptr));
        tCategorie->setText(QCoreApplication::translate("LecteurVue", "Cat\303\251gorie", nullptr));
        label_4->setText(QCoreApplication::translate("LecteurVue", "|", nullptr));
        label_3->setText(QString());
        tNum->setText(QCoreApplication::translate("LecteurVue", "NumImage", nullptr));
        label_5->setText(QCoreApplication::translate("LecteurVue", "/", nullptr));
        tNbrImage->setText(QCoreApplication::translate("LecteurVue", "NbrImage", nullptr));
        lancer->setText(QCoreApplication::translate("LecteurVue", "Lancer le diaporame", nullptr));
        arreter->setText(QCoreApplication::translate("LecteurVue", "Arr\303\252ter le diaporame", nullptr));
        menuFichier->setTitle(QCoreApplication::translate("LecteurVue", "Fichier", nullptr));
        menuParam->setTitle(QCoreApplication::translate("LecteurVue", "Param\303\250tres", nullptr));
        menuAide->setTitle(QCoreApplication::translate("LecteurVue", "Aide", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LecteurVue: public Ui_LecteurVue {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LECTEURVUE_H
