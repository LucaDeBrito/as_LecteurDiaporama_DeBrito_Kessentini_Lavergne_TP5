#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QMainWindow>
#include <QDebug>
#include <QMessageBox>
#include <image.h>
#include <lecteur.h>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QGraphicsScene>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class LecteurVue; }
QT_END_NAMESPACE

class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(QWidget *parent = nullptr);
    ~LecteurVue();

private:
    QTimer* timer;

private slots :

    void arreter();
    void lancer();
    void suivant();
    void precedent();
    void quitter();
    void aProposDe();
    void modeAuto();
    void chargerImage();
    void majTitre();
    void majCategorie();
    void majNumero();

private:
    Ui::LecteurVue *ui;
    Lecteur MonLecteur;
    int duree;
};
#endif // LECTEURVUE_H
