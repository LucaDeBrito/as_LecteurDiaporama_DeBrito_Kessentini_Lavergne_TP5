#include "lecteurvue.h"
#include "ui_lecteurvue.h"

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);

    duree=1000; //duree du timer

    connect(ui->precedent, SIGNAL(clicked()), this, SLOT(precedent()));     //bouton precedent
    connect(ui->lancer, SIGNAL(clicked()), this, SLOT(lancer()));           //bouton lancer
    connect(ui->arreter, SIGNAL(clicked()), this, SLOT(arreter()));         //bouton arreter
    connect(ui->suivant, SIGNAL(clicked()), this, SLOT(suivant()));         //bouton suivant
    connect(ui->quitter, SIGNAL(triggered()), this, SLOT(quitter()));       //option quitter
    connect(ui->aProposDe, SIGNAL(triggered()), this, SLOT(aProposDe()));   //option a propos de
    connect(ui->precedent, SIGNAL(clicked()), this, SLOT(arreter()));         //bouton arreter
    connect(ui->suivant, SIGNAL(clicked()), this, SLOT(arreter()));         //bouton arreter
    MonLecteur.changerDiaporama(1);

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(modeAuto()));  //quand le timer tombe à 0, il exécute le slot

    chargerImage();
    majCategorie();
    majTitre();
    majNumero();

    MonLecteur.afficher();
}

LecteurVue::~LecteurVue()
{
    delete ui;
}

void LecteurVue::lancer()
{
    qDebug() << "Je lance";

    ui->lancer->setEnabled(false);  //désactive le bouton lancer

    ui->arreter->setEnabled(true);  //active le bouton arret

    timer->start(duree);    //démare le timer
}

void LecteurVue::modeAuto()
{   //il passe au suivant en gros

    suivant();

    timer->start(duree);
}

void LecteurVue::arreter()
{
    //qDebug() << "J'arrete";

    timer->stop();  //arret du timer

    ui->lancer->setEnabled(true);   //active le bouton lancer

    ui->arreter->setEnabled(false); //désactive le bouton arret
}

//Permet de passer à l'image suivante
void LecteurVue::suivant()
{
    MonLecteur.avancer();
    chargerImage();
    majCategorie();
    majTitre();
    majNumero();
}

//Permet de passer à l'image précédente
void LecteurVue::precedent()
{
    MonLecteur.reculer();
    chargerImage();
    majCategorie();
    majTitre();
    majNumero();
}

void LecteurVue::quitter()
{
    this->close();
}

void LecteurVue::aProposDe()
{
    //Il faudra que l'on utilise un QDialog ou que l'on trouve comment faire des retours de ligne

    QMessageBox msgBox;
    msgBox.setText("Version : 3 | "
                   "Date de dernière modification : 11/05/2023 | "
                   "Auteur : DE BRITO Luca, KESSENTINI Nour, LAVERGNE Elsa");
    msgBox.exec();
}

//Permet de charger l'image directement
void LecteurVue::chargerImage()
{
    ui->Image->setPixmap(QString::fromStdString(MonLecteur.imageCourante()->getChemin()));
}

//Permet de mettre à jour le titre de l'image sur la fenêtre
void LecteurVue::majTitre()
{
    ui->tTitre->setText(QString::fromStdString(MonLecteur.imageCourante()->getTitre()));
}

//permet de mettre à jour la catégorie de l'image
void LecteurVue::majCategorie()
{
    ui->tCategorie->setText(QString::fromStdString(MonLecteur.imageCourante()->getCategorie()));
}

//Modifier le titre de l'image sur la fenêtre
void LecteurVue::majNumero()
{
    ui->tNum->setText(QString::number(MonLecteur.imageCourante()->getRang()));
}
