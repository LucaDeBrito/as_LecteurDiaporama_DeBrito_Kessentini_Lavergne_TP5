#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QMainWindow>
#include <QDebug>
#include <QMessageBox>
#include <image.h>
#include <lecteur.h>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QGraphicsScene>
#include <QTimer>
#include <QInputDialog>
#include "choixdiapo.h"

QT_BEGIN_NAMESPACE
namespace Ui { class LecteurVue; }
QT_END_NAMESPACE

class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(QWidget *parent = nullptr);
    ~LecteurVue();

private:
    QTimer* timer;

private slots :

    void arreter();                             //Permet d'arrêter le diaporama lorsqu'il est en mode auto et le refait passer en mode manuel
    void lancer();                              //Permet de lancer le diaporama en mode automatique
    void suivant();                             //Permet de passer à l'image suivante
    void precedent();                           //Permet de passer à l'image précédente
    void quitter();                             //Permet de quitter l'application
    void aProposDe();                           //Permet d'afficher des informations sur la version du diaporama
    void modeAuto();                            //Permettait de faire défiler les images lorsque le diaporama est en mode automatique
    void chargerImage();                        //Getter pour charger les images via leur chemin d'accès et pour les afficher à l'écran
    void majTitre();                            //Permet de mettre à jour le titre
    void majCategorie();                        //Permet de mettre à jour la catégorie de l'image
    void majNumero();                           //Permet de mettre à jour le numéro de l'image
    void chargerDiaporama(unsigned int);        //Permet de charger le diaporama lorsqu'il a été choisi
    void choisirDiapo();                        //Permet de choisir le diaporama à afficher
    void enleverDiaporama();                    //Enlève le diaporama chargé

private:
    Ui::LecteurVue *ui;
    Lecteur MonLecteur;
    int duree;                                  //la durée de défilement en mode auto du diaporama
};
#endif // LECTEURVUE_H
