#include "lecteurvue.h"
#include "ui_lecteurvue.h"

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);

    duree=1000; //duree du timer

    connect(ui->precedent, SIGNAL(clicked()), this, SLOT(precedent()));             //bouton precedent
    connect(ui->lancer, SIGNAL(clicked()), this, SLOT(lancer()));                   //bouton lancer
    connect(ui->arreter, SIGNAL(clicked()), this, SLOT(arreter()));                 //bouton arreter
    connect(ui->suivant, SIGNAL(clicked()), this, SLOT(suivant()));                 //bouton suivant
    connect(ui->quitter, SIGNAL(triggered()), this, SLOT(quitter()));               //option quitter
    connect(ui->aProposDe, SIGNAL(triggered()), this, SLOT(aProposDe()));           //option a propos de
    connect(ui->precedent, SIGNAL(clicked()), this, SLOT(arreter()));               //bouton arreter
    connect(ui->suivant, SIGNAL(clicked()), this, SLOT(arreter()));                 //bouton arreter
    connect(ui->chargerDiapo, SIGNAL(triggered()), this, SLOT(choisirDiapo()));     //bouton Paramètres>>Charger Diaporama
    connect(ui->actionenleverDiapo, SIGNAL(triggered()), this, SLOT(enleverDiaporama()));     //bouton Paramètres>>Charger Diaporama


    //Désactiver tous les boutons au départ avant de lancer le diaporama
    ui->lancer->setEnabled(false);  //désactive le bouton lancer
    ui->arreter->setEnabled(false);  //désactive le bouton arret
    ui->suivant->setEnabled(false);  //désactive le bouton suivant
    ui->precedent->setEnabled(false);  //désactive le bouton precedent

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(modeAuto()));  //quand le timer tombe à 0, il exécute le slot

    MonLecteur.afficher();                                      //Servait à afficher directement les informations relatives à l'image. Désormais inutile
}

LecteurVue::~LecteurVue()
{
    delete ui;
}

void LecteurVue::lancer()
{
    ui->mode->setText("Mode : Auto");
    ui->lancer->setEnabled(false);  //désactive le bouton lancer

    ui->arreter->setEnabled(true);  //active le bouton arret

    timer->start(duree);            //démarre le timer
}

void LecteurVue::modeAuto()
{                                   //il passe au suivant

    suivant();

    timer->start(duree);
}

void LecteurVue::arreter()
{
    //qDebug() << "J'arrete";
    ui->mode->setText("Mode : Manuel");
    timer->stop();                  //arrêt du timer

    ui->lancer->setEnabled(true);   //active le bouton lancer

    ui->arreter->setEnabled(false); //désactive le bouton arrêt
}

//Permet de passer à l'image suivante
void LecteurVue::suivant()
{
    ui->mode->setText("Mode : Manuel");
    MonLecteur.avancer();
    chargerImage();
    majCategorie();
    majTitre();
    majNumero();
}

//Permet de passer à l'image précédente
void LecteurVue::precedent()
{
    ui->mode->setText("Mode : Manuel");
    MonLecteur.reculer();
    chargerImage();
    majCategorie();
    majTitre();
    majNumero();
}

void LecteurVue::quitter()
{
    this->close();
}

void LecteurVue::aProposDe()
{
    //Il faudra que l'on utilise un QDialog ou que l'on trouve comment faire des retours de ligne

    QMessageBox msgBox;
    msgBox.setText("Version : 4 | "
                   "Date de dernière modification : 17/05/2023 | "
                   "Auteur : DE BRITO Luca, KESSENTINI Nour, LAVERGNE Elsa");
    msgBox.exec();
}

//Permet de charger l'image directement
void LecteurVue::chargerImage()
{
    if (MonLecteur.nbImages() != 0)
    {
        ui->Image->setPixmap(QString::fromStdString(MonLecteur.imageCourante()->getChemin()));
    }
    else
    {
        ui->Image->setText(QString(""));
    }
}

//Permet de mettre à jour le titre de l'image sur la fenêtre
void LecteurVue::majTitre()
{
    if (MonLecteur.nbImages() != 0)
    {
        ui->tTitre->setText(QString::fromStdString(MonLecteur.imageCourante()->getTitre()));
    }
    else
    {
        ui->tTitre->setText(QString("Titre"));
    }
}

//permet de mettre à jour la catégorie de l'image
void LecteurVue::majCategorie()
{
    if (MonLecteur.nbImages() != 0)
    {
        ui->tCategorie->setText(QString::fromStdString(MonLecteur.imageCourante()->getCategorie()));
    }
    else
    {
        ui->tCategorie->setText(QString("Catégorie"));
    }
}

//Modifier le titre de l'image sur la fenêtre
void LecteurVue::majNumero()
{
    if (MonLecteur.nbImages() != 0)
    {
        ui->tNum->setText(QString::number(MonLecteur.imageCourante()->getRang()));
    }
    else
    {
        ui->tNum->setText(QString("NumImage"));
    }
}

//Permet de choisir le diaporama que l'utilisateur veut afficher
void LecteurVue::choisirDiapo()
{
    ChoixDiapo fenChoix(this);
    bool reponse = fenChoix.exec();                 //Ouverture fenêtre de dialogue
    int numDiaporama = fenChoix.getNumDiapo();      //Récupération du numéro de diaporama
    if (reponse==QDialog::Accepted)
    {
        chargerDiaporama(numDiaporama);             //Chargement du diaporama
    }
}

//Charge le diaporama
void LecteurVue::chargerDiaporama(unsigned int n)
{
    //Lance changer diaporama pour modifier le numéro du diaporama obtenu dans choisirDiapo()
    MonLecteur.changerDiaporama(n);

    //Si le diaporama n'est pas vide, on charge les images et active les boutons
    if (MonLecteur.nbImages() != 0)
    {
        ui->mode->setText("Mode : Manuel");
        chargerImage();
        majCategorie();
        majTitre();
        majNumero();
        ui->lancer->setEnabled(true);  //active le bouton lancer
        ui->suivant->setEnabled(true);  //active le bouton suivant
        ui->precedent->setEnabled(true);  //active le bouton precedent
    }
    //Sinon, on désactive les boutons et recharge
    else
    {
        enleverDiaporama();
    }
}

//Permet d'enlever le diaporama en cours
void LecteurVue::enleverDiaporama()
{
    MonLecteur.changerDiaporama(0);
    ui->lancer->setEnabled(false);      //désactive le bouton lancer
    ui->arreter->setEnabled(false);     //désactive le bouton arret
    ui->suivant->setEnabled(false);     //désactive le bouton suivant
    ui->precedent->setEnabled(false);   //désactive le bouton precedent
    chargerImage();
    majCategorie();
    majTitre();
    majNumero();
    ui->mode->setText("Mode : ___");
}

