/********************************************************************************
** Form generated from reading UI file 'choixdiapo.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHOIXDIAPO_H
#define UI_CHOIXDIAPO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ChoixDiapo
{
public:
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QSpinBox *numDiaporama;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *ChoixDiapo)
    {
        if (ChoixDiapo->objectName().isEmpty())
            ChoixDiapo->setObjectName(QString::fromUtf8("ChoixDiapo"));
        ChoixDiapo->resize(400, 300);
        verticalLayout = new QVBoxLayout(ChoixDiapo);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label = new QLabel(ChoixDiapo);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setMaximumSize(QSize(500, 500));

        verticalLayout_2->addWidget(label);

        numDiaporama = new QSpinBox(ChoixDiapo);
        numDiaporama->setObjectName(QString::fromUtf8("numDiaporama"));

        verticalLayout_2->addWidget(numDiaporama);

        buttonBox = new QDialogButtonBox(ChoixDiapo);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout_2->addWidget(buttonBox);


        verticalLayout->addLayout(verticalLayout_2);


        retranslateUi(ChoixDiapo);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, ChoixDiapo, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, ChoixDiapo, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(ChoixDiapo);
    } // setupUi

    void retranslateUi(QDialog *ChoixDiapo)
    {
        ChoixDiapo->setWindowTitle(QCoreApplication::translate("ChoixDiapo", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("ChoixDiapo", "Veuillez choisir le num\303\251ro du Diaporama que vous chargez", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ChoixDiapo: public Ui_ChoixDiapo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHOIXDIAPO_H
