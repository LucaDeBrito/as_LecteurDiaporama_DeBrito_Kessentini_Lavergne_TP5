#include "lecteurvue.h"
#include "ui_lecteurvue.h"

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{

    //Lien vers l'ui
    ui->setupUi(this);

    //Signals/slots connectés aux différents boutons
    connect(ui->precedent, SIGNAL(clicked()), this, SLOT(precedent()));         //Bouton précédent
    connect(ui->lancer, SIGNAL(clicked()), this, SLOT(lancer()));               //Bouton Lancer
    connect(ui->arreter, SIGNAL(clicked()), this, SLOT(arreter()));             //Bouton Arrêter
    connect(ui->suivant, SIGNAL(clicked()), this, SLOT(suivant()));             //Bouton Suivant
    connect(ui->quitter, SIGNAL(triggered()), this, SLOT(quitter()));           //Bouton Quitter
    connect(ui->aProposDe, SIGNAL(triggered()), this, SLOT(aProposDe()));       //Bouton AProposDe

    //Charge le diaporama à lire
    MonLecteur.changerDiaporama(1);
    //Affiche la première image du diaporama
    chargerImage();
    majCategorie();
    majTitre();
    majNumero();
    ui->mode->setText("Mode : Manuel");
    MonLecteur.afficher();
    ui->NbrImages->setNum(int(MonLecteur.nbImages()));

}

LecteurVue::~LecteurVue()
{
    delete ui;
}

//Permet de lancer le diaporama et de le repasser en mode auto
void LecteurVue::lancer()
{
    qDebug() << "Je lance";
    ui->mode->setText("Mode : Auto");
}

//Permet d'arrêter le diaporama et de le repasser en mode manuel
void LecteurVue::arreter()
{
    qDebug() << "J'arrete";
    ui->mode->setText("Mode : Manuel");
}

//Permet de passer à l'image suivante
void LecteurVue::suivant()
{
    MonLecteur.avancer();
    MonLecteur.afficher();
    chargerImage();
    majCategorie();
    majTitre();
    majNumero();
    ui->mode->setText("Mode : Manuel");
}

//Permet de passer à l'image précédente
void LecteurVue::precedent()
{
    MonLecteur.reculer();
    MonLecteur.afficher();
    chargerImage();
    majCategorie();
    majTitre();
    majNumero();
    ui->mode->setText("Mode : Manuel");
}

//Permet de quitter la fenêtre
void LecteurVue::quitter()
{
    this->close();
}

void LecteurVue::chargerImage()
{
    ui->image->setPixmap(QString::fromStdString(MonLecteur.imageCourante()->getChemin()));
}

//Permet de mettre à jour le titre de l'image sur la fenêtre
void LecteurVue::majTitre()
{
    ui->titre->setText(QString::fromStdString(MonLecteur.imageCourante()->getTitre()));
}

void LecteurVue::majCategorie()
{
    ui->categorie->setText(QString::fromStdString(MonLecteur.imageCourante()->getCategorie()));
}

//Modifier le titre de l'image sur la fenêtre
void LecteurVue::majNumero()
{
    ui->numImage->setText(QString::number(MonLecteur.imageCourante()->getRang()));
}


void LecteurVue::aProposDe()
{
    //Il faudra que l'on utilise un QDialog ou que l'on trouve comment faire des retours de ligne

    QMessageBox msgBox;
    msgBox.setText("Version : 2 | "
                   "Date de dernière modification : 05/05/2023 | "
                   "Auteur : DE BRITO Luca, KESSENTINI Nour, LAVERGNE Elsa");
    msgBox.exec();
}
