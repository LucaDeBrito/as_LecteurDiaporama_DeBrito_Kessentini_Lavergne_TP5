#include "lecteurvue.h"
#include "ui_lecteurvue.h"

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);

    connect(ui->precedent, SIGNAL(clicked()), this, SLOT(precedent()));
    connect(ui->lancer, SIGNAL(clicked()), this, SLOT(lancer()));
    connect(ui->arreter, SIGNAL(clicked()), this, SLOT(arreter()));
    connect(ui->suivant, SIGNAL(clicked()), this, SLOT(suivant()));
    connect(ui->quitter, SIGNAL(triggered()), this, SLOT(quitter()));
    connect(ui->aProposDe, SIGNAL(triggered()), this, SLOT(aProposDe()));
    MonLecteur.changerDiaporama(1);

    scene = new QGraphicsScene();
    ui->image->setScene(scene);

    QImage imgActuelle(QString::fromStdString(MonLecteur.imageCourante()->getChemin()));
    item = new QGraphicsPixmapItem(QPixmap::fromImage(imgActuelle));
    scene->addItem(item);

    MonLecteur.afficher();
}

LecteurVue::~LecteurVue()
{
    delete ui;
}

void LecteurVue::lancer()
{
    qDebug() << "Je lance";
}

void LecteurVue::arreter()
{
    qDebug() << "J'arrete";
}

void LecteurVue::suivant()
{
    qDebug() << "Je passe au suivant";
    MonLecteur.avancer();

    MonLecteur.afficher();

    scene->removeItem(item);

    QImage imgActuelle(QString::fromStdString(MonLecteur.imageCourante()->getChemin()));

    item = new QGraphicsPixmapItem(QPixmap::fromImage(imgActuelle));

    scene->addItem(item);

}

void LecteurVue::precedent()
{
    qDebug() << "Je reviens en arrière";
    MonLecteur.reculer();
    MonLecteur.afficher();
    scene->removeItem(item);
    QImage imgActuelle(QString::fromStdString(MonLecteur.imageCourante()->getChemin()));
    item = new QGraphicsPixmapItem(QPixmap::fromImage(imgActuelle));
    scene->addItem(item);
}

void LecteurVue::quitter()
{
    this->close();
}

void LecteurVue::aProposDe()
{
    //Il faudra que l'on utilise un QDialog ou que l'on trouve comment faire des retours de ligne

    QMessageBox msgBox;
    msgBox.setText("Version : 2 | "
                   "Date de dernière modification : 05/05/2023 | "
                   "Auteur : DE BRITO Luca, KESSENTINI Nour, LAVERGNE Elsa");
    msgBox.exec();
}
