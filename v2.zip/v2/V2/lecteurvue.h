#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QMainWindow>
#include <QDebug>
#include <QMessageBox>
#include <image.h>
#include <lecteur.h>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QGraphicsScene>

QT_BEGIN_NAMESPACE
namespace Ui { class LecteurVue; }
QT_END_NAMESPACE

class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(QWidget *parent = nullptr);
    ~LecteurVue();
    void majTitre();
    void majCategorie();
    void majNumero();
    void chargerImage();

private:
    QGraphicsScene* scene;
    QGraphicsPixmapItem* item;

private slots :

    void arreter();
    void lancer();
    void suivant();
    void precedent();
    void quitter();
    void aProposDe();


private:
    Ui::LecteurVue *ui;
    Lecteur MonLecteur;
};
#endif // LECTEURVUE_H
