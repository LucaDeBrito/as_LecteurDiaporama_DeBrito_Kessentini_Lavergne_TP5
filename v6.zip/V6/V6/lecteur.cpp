#include "lecteur.h"

Lecteur::Lecteur()
{
    db=new baseDeDonnees;
    Diaporama.setNumDiaporamaCourant(0);   // =  le lecteur est vide
}

void Lecteur::avancer()
{
    Diaporama.avancerDansDiaporama();
}

void Lecteur::reculer()
{
    Diaporama.reculerDansDiaporama();
}

void Lecteur::changerDiaporama(unsigned int pNumDiaporama)
{
    qDebug()<< "changerDiapo";
    // s'il y a un diaporama courant, le vider, puis charger le nouveau Diaporama
    if (Diaporama.numDiaporamaCourant() > 0)
    {
        viderDiaporama();
    }
    Diaporama.setNumDiaporamaCourant(pNumDiaporama);
    if (Diaporama.numDiaporamaCourant() > 0)
    {
        chargerDiaporama(); // charge le diaporama courant
    }
}

void Lecteur::chargerDiaporama()
{
    qDebug()<< "chargerDiaporama";
    /* Chargement des images associées au diaporama courant via la base de données nodenot_bd9*/

    Image* imageACharger;
    QSqlQuery query;
    query.prepare("SELECT DiaposDansDiaporama.rang, Diapos.titrePhoto, Familles.nomFamille, Diapos.uriPhoto FROM DiaposDansDiaporama JOIN Diaporamas ON Diaporamas.idDiaporama = DiaposDansDiaporama.idDiaporama JOIN Diapos ON DiaposDansDiaporama.idDiapo = Diapos.idphoto JOIN Familles ON Familles.idFamille = Diapos.idFam WHERE DiaposDansDiaporama.idDiaporama = :idDiapo");
    query.bindValue(":idDiapo", Diaporama.numDiaporamaCourant());
    query.exec();
    for(int i=0 ; query.next() ;i++)
    {
        qDebug()<< query.value(0) << query.value(1) << query.value(2) << query.value(3);
        imageACharger= new Image(query.value(0).toInt(), query.value(2).toString().toStdString(), query.value(1).toString().toStdString(), ":"+query.value(3).toString().toStdString());
        Diaporama.ajouterImage(imageACharger);
    }

    Diaporama.trierDiaporama();    //Trie le diaporama avant de le démarrer

     cout << "Diaporama num. " << Diaporama.numDiaporamaCourant() << " selectionne. " << endl;
     cout << Diaporama.nbImages() << " images chargees dans le diaporama" << endl;

}

void Lecteur::viderDiaporama()
{
    qDebug()<< "Vider";
    if (Diaporama.nbImages() > 0)
    {
        unsigned int taille = Diaporama.nbImages();
        for (unsigned int i = 0; i < taille ; i++)
        {
            Diaporama.supprimerImage();
        }
    }
    cout << Diaporama.nbImages() << " images restantes dans le diaporama." << endl;

}

void Lecteur::afficher()
{
    qDebug()<< "Afficher";
    /* affiche les information sur le lecteur :
     * 1) vide (si num. de diaporama = 0) OU BIEN  numéro de diaporama affiché
     * 2) Si un diaporama courant est chargé (num. de diaporama > 0), affiche l'image courante OU BIEN 'diaporama vide'
     *     si ce diaporama n'a aucun image */
    if(Diaporama.numDiaporamaCourant()==0)
           {
               cout<<"Vide"<<endl;
           }
           else
            {
              if(Diaporama.numDiaporamaCourant() > 0)
              {
                  imageCourante()->Image::afficher();
              }
              else
              {
                  cout << "diaporama vide";
              }

    }
}

Image* Lecteur::imageCourante()
{
    return Diaporama.imageCourante();
}

unsigned int Lecteur::nbImages()
{
    return Diaporama.nbImages();
}
