#include "lecteur_diaporama.h"

lecteur_Diaporama::lecteur_Diaporama()
{
    _posImageCourante=0;
}

lecteur_Diaporama::~lecteur_Diaporama()
{

}

//trie les images dans l'ordre de leur rang dans le diaporama
void lecteur_Diaporama::trierDiaporama()
{
    for(unsigned int i = 0 ; i < nbImages()-1 ; i++)
    {
        for(unsigned int j = 0 ; j < nbImages()-1-i ; j++)
        {
            if (_Diaporama[j]->getRang() >_Diaporama[j+1]->getRang() )
            {
                Image* saladier=_Diaporama[j];
                _Diaporama[j]=_Diaporama[j+1];
                _Diaporama[j+1]=saladier;
            }
        }
    }
    _posImageCourante = 0;
}

unsigned int lecteur_Diaporama::numDiaporamaCourant()
{
    return _idDiaporama;
}

void lecteur_Diaporama::setNumDiaporamaCourant(unsigned int pidDiapo)
{
    _idDiaporama = pidDiapo;
}

void lecteur_Diaporama::ajouterImage(Image* imageAjoutee)
{
    _Diaporama.push_back(imageAjoutee);
}

void lecteur_Diaporama::supprimerImage()
{
    _Diaporama.pop_back();
}

unsigned int lecteur_Diaporama::nbImages()
{
    return _Diaporama.size();
}

Image* lecteur_Diaporama::imageCourante()
{
    return _Diaporama[_posImageCourante];
}

void lecteur_Diaporama::avancerDansDiaporama()
{
    unsigned int indiceR;
        indiceR=_posImageCourante;
        if (indiceR<nbImages()-1)
        {
            _posImageCourante=indiceR+1;
        }
        else
        {
            _posImageCourante=0;
        }
}

void lecteur_Diaporama::reculerDansDiaporama()
{
    unsigned int indiceR;
        indiceR=_posImageCourante;
        if (indiceR>0)
        {
            _posImageCourante=indiceR-1;
        }
        else
        {
            _posImageCourante = nbImages()-1;
        }
}
