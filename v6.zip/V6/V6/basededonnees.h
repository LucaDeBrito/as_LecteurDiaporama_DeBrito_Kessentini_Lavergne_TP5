#ifndef BASEDEDONNEES_H
#define BASEDEDONNEES_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlQueryModel>

#define DATABASE_NAME "nodenot_bd9"
#define CONNECT_TYPE "QODBC"

class baseDeDonnees
{
public:
    baseDeDonnees();
    bool openDatabase();        //Permet d'ouvrir la base de données
    void closeDatabase();       //Permet de fermer la base de données

private:
    QSqlDatabase db;

};

#endif // BASEDEDONNEES_H
