#include "vitesse.h"
#include "ui_vitesse.h"

Vitesse::Vitesse(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Vitesse)
{
    setSpeed();
    ui->setupUi(this);
    connect(ui->x025, SIGNAL(clicked()), this, SLOT(setSpeed025()));
    connect(ui->x05, SIGNAL(clicked()), this, SLOT(setSpeed05()));
    connect(ui->x075, SIGNAL(clicked()), this, SLOT(setSpeed075()));
    connect(ui->x1, SIGNAL(clicked()), this, SLOT(setSpeed()));
    connect(ui->x125, SIGNAL(clicked()), this, SLOT(setSpeed125()));
    connect(ui->x15, SIGNAL(clicked()), this, SLOT(setSpeed15()));
    connect(ui->x175, SIGNAL(clicked()), this, SLOT(setSpeed175()));
    connect(ui->x2, SIGNAL(clicked()), this, SLOT(setSpeed2()));
}

Vitesse::~Vitesse()
{
    delete ui;
}

void Vitesse::setSpeed()
{
    speed = 1000;
    qDebug() << speed;
}

float Vitesse::getSpeed()
{
    return speed;
}

void Vitesse::setSpeed025()
{
    speed = 4000;
    qDebug() << speed;
}

void Vitesse::setSpeed05()
{
    speed = 2000;
    qDebug() << speed;
}

void Vitesse::setSpeed075()
{
    speed = 1333;
    qDebug() << speed;
}

void Vitesse::setSpeed125()
{
    speed = 800;
    qDebug() << speed;
}

void Vitesse::setSpeed15()
{
    speed = 667;
    qDebug() << speed;
}

void Vitesse::setSpeed175()
{
    speed = 571;
    qDebug() << speed;
}

void Vitesse::setSpeed2()
{
    speed = 500;
    qDebug() << speed;
}
