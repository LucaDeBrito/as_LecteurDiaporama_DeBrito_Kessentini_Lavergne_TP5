#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QMainWindow>
#include <QDebug>
#include <QMessageBox>
#include "image.h"
#include "lecteur.h"
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QGraphicsScene>
#include <QTimer>
#include "vitesse.h"
#include "choixdiapo.h"
#include "basededonnees.h"
#include "lecteur_Diaporama.h"

QT_BEGIN_NAMESPACE
namespace Ui { class LecteurVue; }
QT_END_NAMESPACE

class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(QWidget *parent = nullptr);
    ~LecteurVue();
    void chargerDiaporama(unsigned int);        //Permet de charger un diaporama
    baseDeDonnees* db;                          //La base de données consultée par l'application

private slots :
    void arreter();         //Arrête le mode auto et lance le mode manuel
    void lancer();          //Arrête le mode manuel et lance le mode auto
    void suivant();         //Permet de passer à l'image suivante
    void precedent();       //Permet de passer à l'image précédente
    void quitter();         //Permet de quitter l'application
    void aProposDe();       //Permet d'afficher des informations sur la version du diaporama
    void modeAuto();        //Permet de faire défiler les images en mode automatique
    void chargerImage();    //Permet de charger une image et de la mettre sur l'application
    void majTitre();        //Met à jour le label Titre avec le titre de l'image
    void majCategorie();    //Met à jour le label Catégorie avec la catégorie de l'image
    void majNumero();       //Met à jour le label Numéro avec le numéro de l'image
    void dialogVitesse();   //Permet de gérer la vitesse du diaporama en mode auto
    void enleverDiapo();    //Permet d'enlever le diaporama actuel
    void choisirDiapo();    //Permet de choisir un diaporama à lire via une fenêtre de dialogue


private:
    Ui::LecteurVue *ui;
    Lecteur MonLecteur;             //Le lecteur de diaporama
    int duree;                      //La durée utilisée pour le timer d'affichage du diaporama
    Vitesse vitesse;                //La vitesse à laquelle devront défiler les images
    QTimer* timer;                  //Timer du diaporama
};
#endif // LECTEURVUE_H
