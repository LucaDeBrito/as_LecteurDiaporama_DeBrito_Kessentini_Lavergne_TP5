#ifndef LECTEUR_DIAPORAMA_H
#define LECTEUR_DIAPORAMA_H
#include <iostream>
using namespace std;
#include "image.h"
#include <QDebug>
#include <vector>

typedef vector<Image*> Diaporama;      //Diaporama contenant les images

class lecteur_Diaporama
{
public:
    lecteur_Diaporama();
    ~lecteur_Diaporama();
    void trierDiaporama();                      //Permet de trier le diaporama
    unsigned int numDiaporamaCourant();         //Obtient l'id du diaporama courant
    void setNumDiaporamaCourant(unsigned int);  // Permet de changer le diaporama courant
    void ajouterImage(Image*);                   //Permet d'ajouter un image dans le diaporama
    void supprimerImage();                      //Permet de supprimer une image du diaporama
    unsigned int nbImages();                    // affiche la taille de _diaporama
    Image* imageCourante();                     // retourne le pointeur vers l'image courante
    void avancerDansDiaporama();
    void reculerDansDiaporama();


private:
    unsigned int _idDiaporama;                       //L'id du diaporama courant
    string _titreDiapo;                             //Titre du diaporama
    int _vitesseDefilement;                         //Vitesse de défilement d'un diaporama
    Diaporama _Diaporama;                          //diaporama lu
    unsigned int _posImageCourante;                 //position de l'image courante dans le diaporama

};

#endif // LECTEUR_DIAPORAMA_H
