#ifndef LECTEUR_H
#define LECTEUR_H
#include "image.h"
#include "basededonnees.h"
#include <QString>
#include <QCoreApplication>
#include "lecteur_diaporama.h"

class Lecteur
{
public:
    Lecteur();
    void avancer();                                         // incrémente _posImageCourante, modulo nbImages()
    void reculer();                                         // décrémente _posImageCourante, modulo nbImages()
    void changerDiaporama(unsigned int pNumDiaporama);      // permet de charger toutes les informations du diaporama depuis la base de données
    void afficher();                                        // affiche les informations sur lecteur-diaporama et l'image courante
    Image* imageCourante();                     // retourne le pointeur vers l'image courante
    unsigned int nbImages();


private:
    baseDeDonnees* db;                                      //base de données lues dans le lecteur
    lecteur_Diaporama Diaporama;                           //Diaporama lu par le lecteur

private:
    void chargerDiaporama();                                // charge dans _diaporama les images du _numDiaporamaCourant
    void viderDiaporama();                                  // vide _diaporama de tous ses objets image et les delete
};

#endif // LECTEUR_H
